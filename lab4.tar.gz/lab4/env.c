#include <stdio.h>
#include "util.h"
#include "symbol.h"
#include "env.h"

/*Lab4: Your implementation of lab4*/

E_enventry E_VarEntry(Ty_ty ty)
{
	return NULL;
}

E_enventry E_FunEntry(Ty_tyList formals, Ty_ty result)
{
	return NULL;
}

S_table E_base_tenv(void)
{
	return NULL;
}

S_table E_base_venv(void)
{
	return NULL;
}
